<?php

use Respect\Validation\Exceptions\NestedValidationExceptionInterface;
use Respect\Validation\Exceptions\ValidationException;
use Slim\Slim;
use Respect\Validation\Validator as v;

require 'vendor/autoload.php';
$app = new Slim(array(//    'debug' => true
));

$app->error(function (\Exception $e) use ($app) {
    $response = [
        "errors" => [
            "An unknown error happened"
        ]
    ];

    $app->response->body(json_encode($response));
});

$pdo = new PDO('mysql:host=localhost;dbname=serialize', 'root', '');
$pdo->exec('SET CHARACTER SET utf8');
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


$app->group('/user', function () use ($app) {
    $app->post('/session', function () use ($app) {
        $jsonBody = json_decode($app->request->getBody());

        try {
            v::attribute(
                'authCredentials',
                v::attribute('email', v::notEmpty()->email())
                    ->attribute('password', v::notEmpty())
            )->assert($jsonBody);

            $authCredentials = $jsonBody->authCredentials;

            $response = [
                'currentUser' => [
                    'email' => 'florandara@gmail.com',
                    'emailHash' => 'e00cf05e1611a154bc3f5764cebbc822',
                    'firstName' => 'Floran',
                    'lastName' => 'NARENJI-SHESHKALANI'
                ]
            ];

            $app->response->body(json_encode($response));
        } catch (NestedValidationExceptionInterface $e) {
            $app->response->body(json_encode([
                'errors' => $e->findMessages([
                    'notEmpty' => 'email must not be empty',
                    'email' => '{{name}} must be a valid email address'
                ])
            ]));
        }
    });
});

$app->get('/hello/:name', function ($name) {
    echo "Hello, $name";
});


$app->run();
